﻿namespace DAL_Celebrity_MSSQL
{
    public interface IRepository : DAL_Celebrity.IRepository<Celebrity, LifeEvent> { }

    public class Celebrity // Знаменитость
    {
        public Celebrity() { this.FullName = string.Empty; this.Nationality = string.Empty; } // конструктор
        public int Id { get; set; }                     // Id Знаменитости
        public string FullName { get; set; }            // полное имя Знаменитости
        public string Nationality { get; set; }         // гражданство Знаменитости (2 символв ISO)
        public string? ReqPhotoPath { get; set; }       // request path фотографии Знаменитости
        public virtual bool Update(Celebrity celebrity)
        {
            if (celebrity == null) return false;

            this.FullName = celebrity.FullName;
            this.Nationality = celebrity.Nationality;
            this.ReqPhotoPath = celebrity.ReqPhotoPath;

            return true;
        }
    }

    public class LifeEvent  // Событие в жизни знаменитости
    {
        public LifeEvent() { this.Description = string.Empty; } // конструктор
        public int Id { get; set; }                     // Id События
        public int CelebrityId { get; set; }            // Id Знаменитости
        public DateTime? Date { get; set; }             // дата События
        public string Description { get; set; }         // описание События
        public string? ReqPhotoPath { get; set; }       // request path фотографии События
        public virtual bool Update(LifeEvent lifeevent) // вспомогательный метод
        {
            if (lifeevent == null) return false;

            bool isUpdated = false;
            if (lifeevent.CelebrityId != 0) { this.CelebrityId = lifeevent.CelebrityId; isUpdated = true; }
            if (lifeevent.Date.HasValue) { this.Date = lifeevent.Date; isUpdated = true; }
            if (!string.IsNullOrEmpty(lifeevent.Description)) { this.Description = lifeevent.Description; isUpdated = true; }
            if (lifeevent.ReqPhotoPath != null) { this.ReqPhotoPath = lifeevent.ReqPhotoPath; isUpdated = true; }
            return isUpdated;
        }
    }
}