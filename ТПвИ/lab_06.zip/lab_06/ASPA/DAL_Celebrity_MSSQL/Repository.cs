﻿namespace DAL_Celebrity_MSSQL
{
    public class Repository : IRepository
    {
        Context context;

        public Repository() { this.context = new Context(); }
        public Repository(string connectionString) { this.context = new Context(connectionString); }
        public static IRepository Create() { return new Repository(); }
        public static IRepository Create(string connectionString) { return new Repository(connectionString); }

        public bool AddCelebrity(Celebrity celebrity)
        {
            try
            {
                context.Celebrities.Add(celebrity);
                return context.SaveChanges() > 0;
            }
            catch { return false; }
        }

        public bool AddLifeevent(LifeEvent lifeevent)
        {
            try
            {
                context.LifeEvents.Add(lifeevent);
                return context.SaveChanges() > 0;
            }
            catch { return false; }
        }

        public bool DelCelebrity(int id)
        {
            Celebrity? celebrity = GetCelebrityById(id);
            if (celebrity == null) return false;

            try
            {
                context.Celebrities.Remove(celebrity);
                return context.SaveChanges() > 0;
            }
            catch { return false; }
        }

        public bool DelLifeevent(int id)
        {
            LifeEvent? lifeevent = GetLifeeventbyId(id);
            if (lifeevent == null) return false;

            try
            {
                context.LifeEvents.Remove(lifeevent);
                return context.SaveChanges() > 0;
            }
            catch { return false; }
        }

        public List<Celebrity> GetAllCelebrities()
        {
            return this.context.Celebrities.ToList<Celebrity>();
        }

        public List<LifeEvent> GetAllLifeevents()
        {
            return this.context.LifeEvents.ToList<LifeEvent>();
        }

        public Celebrity? GetCelebrityById(int id)
        {
            return this.context.Celebrities.FirstOrDefault(c => c.Id == id);
        }

        public Celebrity? GetCelebrityByLifeeventId(int lifeeventId)
        {
            LifeEvent? lifeevent = GetLifeeventbyId(lifeeventId);
            if (lifeevent == null) return null;

            return this.GetCelebrityById(lifeevent.CelebrityId);
        }

        public int GetCelebrityIdByName(string name)
        {
            var celebrity = this.context.Celebrities.FirstOrDefault(c => c.FullName.Contains(name));
            return celebrity?.Id ?? -1;
        }

        public LifeEvent? GetLifeeventbyId(int id)
        {
            return this.context.LifeEvents.FirstOrDefault(l => l.Id == id);
        }

        public List<LifeEvent> GetLifeeventsByCelebrityId(int celebrityId)
        {
            return this.context.LifeEvents.Where(l => l.CelebrityId == celebrityId).ToList();
        }

        public bool UpdCelebrity(int id, Celebrity celebrity)
        {
            Celebrity? existingleCelebrity = GetCelebrityById(id);
            if (existingleCelebrity == null) return false;

            try
            {
                existingleCelebrity.Update(celebrity);
                return this.context.SaveChanges() > 0;
            }
            catch { return false; }
        }

        public bool UpdLifeevent(int id, LifeEvent lifeevent)
        {
            LifeEvent? existingleLifeevent = GetLifeeventbyId(id);
            if (existingleLifeevent == null) return false;

            try
            {
                existingleLifeevent.Update(lifeevent);
                return this.context.SaveChanges() > 0;
            }
            catch { return false; }
        }
        public void Dispose() => context?.Dispose();
    }
}
