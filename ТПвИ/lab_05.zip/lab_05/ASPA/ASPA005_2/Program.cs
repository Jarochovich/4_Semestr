using DAL004;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileProviders;
using System.Net;
using Validation;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

string path = "Celebrities";
Repository repository = new Repository(path);

RouteGroupBuilder api = app.MapGroup("/Celebrities");

app.UseExceptionHandler("/Celebrities/Error");

api.MapGet("", () => repository.GetAllCelebrities());

api.MapGet("/{id:int}", (int id) =>
{
    Celebrity? celebrity = repository?.GetCelebrityById(id);
    if (celebrity == null) throw new FoundByIdException($"Celebrity Id = {id}");
    return celebrity;
});

SurnameFilter.repository = PhotoExistFilter.repository = UpdateFilter.repository = DeleteFilter.repository = repository;

api.MapPost("", (Celebrity celebrity) =>
{
    int? id = repository.addCelebrity(celebrity);
    if (id == null) throw new AddCelebrityException("/Celebrities error, id == null");
    if (repository.SaveChanges() <= 0) throw new SaveException("/Celerities error, SaveChanges() <= 0");
    return new Celebrity((int)id, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
})
.AddEndpointFilter<PhotoExistFilter>()
.AddEndpointFilter<SurnameFilter>();

api.MapDelete("/{id:int}", (int id) =>
{
    Celebrity? celebrity = repository.GetCelebrityById(id);
    if (celebrity == null) throw new FoundByIdException($"Celebrity Id = {id}");

    repository.deleteCelebtityById(id);
    if (repository.SaveChanges() <= 0)
        throw new DeleteCelebrityException($"Failed to delete celebrity with Id = {id}");

    return $"Celebrity with Id = {id} deleted";
})
.AddEndpointFilter<DeleteFilter>();

api.MapPut("/{id:int}", (int id, Celebrity celebrity) =>
{
    int? newId = null;
    if ((newId = repository.updCelebrityById(id, celebrity)) == null) throw new UpdCelebrityException($"put error: {id}");
    return new Celebrity((int)newId, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
})
.AddEndpointFilter<UpdateFilter>();

app.MapFallback((HttpContext ctx) => Results.NotFound(new { error = $"path {ctx.Request.Path} not supported " }));

api.Map("/Error", (HttpContext ctx) =>
{
    Exception? ex = ctx.Features.Get<IExceptionHandlerFeature>()?.Error;
    IResult rc = Results.Problem(detail: "Panic", instance: app.Environment.EnvironmentName, title: "ASPA004/error", statusCode: 500);
    if (ex != null)
    {
        if (ex is AbsurdeException) rc = Results.Conflict(ex.Message);
        if (ex is ValueException) rc = Results.Conflict(ex.Message);
        if (ex is UpdCelebrityException) rc = Results.Problem(title: "ASPA004/UpdCelebrity", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is DeleteCelebrityException) rc = Results.Problem(title: "ASPA004/DeleteCelebrity", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is FileNotFoundException) rc = Results.Problem(title: "ASPA004/FileNotFoundException", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is FoundByIdException) rc = Results.Problem(title: "ASPA004/FoundById", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is BadHttpRequestException) rc = Results.Problem(title: "ASPA004/BadRequest", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 404);
        if (ex is SaveException) rc = Results.Problem(title: "ASPA004/SaveChanges", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is AddCelebrityException) rc = Results.Problem(title: "ASPA004/addCelebrity", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
    }
    return rc;
});



app.Run();

public class AbsurdeException : Exception { public AbsurdeException(string message) : base($"Absurde: {message}") { } };
public class ValueException : Exception { public ValueException(string message) : base($"Value: {message}") { } };
public class UpdCelebrityException : Exception { public UpdCelebrityException(string message) : base($"UpdCelebrityException error {message}") { } };
public class DeleteCelebrityException : Exception { public DeleteCelebrityException(string message) : base($"Delete by Id: {message}") { } };
public class FoundByIdException : Exception { public FoundByIdException(string message) : base($"Not found by Id: {message}") { } };
public class SaveException : Exception { public SaveException(string message) : base($"SaveChanges error: {message}") { } };
public class AddCelebrityException : Exception { public AddCelebrityException(string message) : base($"AddCelebrityException error {message}") { } };