using DAL004;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.Extensions.FileProviders;
using System.Net;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

string path = "Celebrities";
Repository repository = new Repository(path);

app.UseExceptionHandler("/Celebrities/Error");

app.MapGet("/Celebrities", () => repository.GetAllCelebrities());

app.MapGet("/Celebrities/{id:int}", (int id) =>
{
    Celebrity? celebrity = repository?.GetCelebrityById(id);
    if (celebrity == null) throw new FoundByIdException($"Celebrity Id = {id}");
    return celebrity;
});

app.MapPost("/Celebrities", (Celebrity celebrity) =>
{
    int? id = repository.addCelebrity(celebrity);
    if (id == null) throw new AddCelebrityException("/Celebrities error, id == null");
    if (repository.SaveChanges() <= 0) throw new SaveException("/Celerities error, SaveChanges() <= 0");
    return new Celebrity((int)id, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
})
.AddEndpointFilter(async (context, next) =>
{
    // ���� �������� celebrity == null, �� 500 � ����������
    // ���� Surname == null ��� ��� ����� < 2, �� 409 � ����������
    Celebrity? celebrity = context.GetArgument<Celebrity>(0);
    if (celebrity == null) throw new AbsurdeException("POST /Celebrities error, loc = 001");
    if (celebrity.Surname == null || celebrity.Surname.Length < 2) throw new ValueException("POST /Celebrities error, Surname is wrong");

    return await next(context);
})
.AddEndpointFilter(async (context, next) =>
{
    // ���� �������� celebrity == null, �� 500 � ����������
    // ���� ��� ���� ����� Surname, �� 409 � ����������
    Celebrity? celebrity = context.GetArgument<Celebrity>(0);
    if (celebrity == null) throw new AbsurdeException("POST /Celebrities error, loc = 002");
    if (repository.GetCelebritiesBySurname(celebrity.Surname) != null) throw new ValueException("POST /Celebrities error, Surname is doubled");
    return await next(context);
})
.AddEndpointFilter(async (context, next) =>
{
    // ���� �������� celebrity == null, �� 500 � ����������
    // ���� � BasePath ��� ����� � ������ Path.GetFileName(celebrity.PhotoPath),
    // -- � ������ ��������� X-Celebrity: NotFound = Path.GetFileName(celebrity.PhotoPath)
    Celebrity? celebrity = context.GetArgument<Celebrity>(0);
    object? result = await next(context);
    string fn = Path.GetFileName(celebrity.PhotoPath);
    if (!File.Exists(Path.Combine(repository.BasePath, $"{fn}")))
    {
        if (context != null) context.HttpContext.Response.Headers.Append($"X-Celerity", $"NotFound = {fn}");
    }

    return result;
});



app.MapFallback((HttpContext ctx) => Results.NotFound(new { error = $"path {ctx.Request.Path} not supported " }));

app.Map("/Celebrities/Error", (HttpContext ctx) =>
{
    Exception? ex = ctx.Features.Get<IExceptionHandlerFeature>()?.Error;
    IResult rc = Results.Problem(detail: "Panic", instance: app.Environment.EnvironmentName, title: "ASPA004/xz", statusCode: 500);
    if (ex != null)
    {
        if (ex is AbsurdeException) rc = Results.Conflict(ex.Message);
        if (ex is ValueException) rc = Results.Conflict(ex.Message);
        if (ex is UpdCelebrityException) rc = Results.Problem(title: "ASPA004/UpdCelebrity", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is DeleteCelebrityException) rc = Results.Problem(title: "ASPA004/DeleteCelebrity", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is FileNotFoundException) rc = Results.Problem(title: "ASPA004/FileNotFoundException", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is FoundByIdException) rc = Results.Problem(title: "ASPA004/FoundById", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is BadHttpRequestException) rc = Results.Problem(title: "ASPA004/BadRequest", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 404);
        if (ex is SaveException) rc = Results.Problem(title: "ASPA004/SaveChanges", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is AddCelebrityException) rc = Results.Problem(title: "ASPA004/addCelebrity", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
    }
    return rc;
});

app.MapDelete("/Celebrities/{id:int}", (int id) =>
{
    if (repository.GetCelebrityById(id) == null) throw new DeleteCelebrityException($"DELETE /Celebrities error, Id = {id}");
    repository.deleteCelebtityById(id);
    return $"Celebrity with Id = {id} deleted";
});

app.MapPut("/Celebrities/{id:int}", (int id, Celebrity celebrity) =>
{
    int? newId = null;
    if ((newId = repository.updCelebrityById(id, celebrity)) == null) throw new UpdCelebrityException($"put error: {id}");
    return new Celebrity((int)newId, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
});

app.Run();

public class AbsurdeException : Exception { public AbsurdeException(string message) : base($"Absurde: {message}") { } };
public class ValueException : Exception { public ValueException(string message) : base($"Value: {message}") { } };
public class UpdCelebrityException : Exception { public UpdCelebrityException(string message) : base($"UpdCelebrityException error {message}") { } };
public class DeleteCelebrityException : Exception { public DeleteCelebrityException(string message) : base($"Delete by Id: {message}") { } };
public class FoundByIdException : Exception { public FoundByIdException(string message) : base($"Not found by Id: {message}") { } };
public class SaveException : Exception { public SaveException(string message) : base($"SaveChanges error: {message}") { } };
public class AddCelebrityException : Exception { public AddCelebrityException(string message) : base($"AddCelebrityException error {message}") { } };