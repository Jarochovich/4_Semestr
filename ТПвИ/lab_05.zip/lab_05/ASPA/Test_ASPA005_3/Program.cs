﻿using static System.Net.Mime.MediaTypeNames;

namespace Test_ASPA005_3
{
    internal class Programm
    {
        private static async Task Main(string[] args)
        {
            await TestAspa();
        }

        public async static Task TestAspa()
        {
            Test test = new Test();

            Console.WriteLine("-- /A ----------------------------------------------------------");
            await test.ExecuteGET("http://localhost:5078/A/3", (int? x, int? y, int status) => x == 3 && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET("http://localhost:5078/A/-3", (int? x, int? y, int status) => x == -3 && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET("http://localhost:5078/A/118", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePOST("http://localhost:5078/A/5", (int? x, int? y, int status) => x == 5 && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecutePOST("http://localhost:5078/A/-5", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePOST("http://localhost:5078/A/118", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePUT("http://localhost:5078/A/2/3", (int? x, int? y, int status) => x == 2 && y == 3 && status == 200 ? Test.OK : Test.NOK);
            await test.ExecutePUT("http://localhost:5078/A/0/3", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePUT("http://localhost:5078/A/25/-3", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePUT("http://localhost:5078/A/0/-3", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecuteDELETE("http://localhost:5078/A/1-99", (int? x, int? y, int status) => x == 1 && y == 99 && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteDELETE("http://localhost:5078/A/99-1", (int? x, int? y, int status) => x == 99 && y == 1 && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteDELETE("http://localhost:5078/A/-1-25", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecuteDELETE("http://localhost:5078/A/-1--25", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecuteDELETE("http://localhost:5078/A/25-101", (int? x, int? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);

            Console.WriteLine("-- /B ------------------------------------------------------------");
            await test.ExecuteGET("http://localhost:5078/B/2.5", (float? x, float? y, int status) => x == 2.5 && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET("http://localhost:5078/B/2", (float? x, float? y, int status) => x == 2.0 && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET("http://localhost:5078/B/2X", (float? x, float? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePOST("http://localhost:5078/B/2.5/3.2", (float? x, float? y, int status) => x == 2.5 && y == 3.2 && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteDELETE("http://localhost:5078/B/2.5-3.2", (float? x, float? y, int status) => x == 2.5 && y == 3.2 && status == 200 ? Test.OK : Test.NOK);

            Console.WriteLine("-- /C -----------------------------------------------");
            await test.ExecuteGET("http://localhost:5078/C/2.5", (bool? x, bool? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecuteGET("http://localhost:5078/C/true", (bool? x, bool? y, int status) => x == true && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecutePOST("http://localhost:5078/C/true,false", (bool? x, bool? y, int status) => x == true && y == false && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteDELETE("http://localhost:5078/C/true,false", (bool? x, bool? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);

            Console.WriteLine("<-- /D ----------------------------------------------->");
            await test.ExecuteGET("http://localhost:5078/D/2025-02-25", (DateTime? x, DateTime? y, int status) => x == new DateTime(2025, 02, 25) && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET("http://localhost:5078/D/2025-02-29", (DateTime? x, DateTime? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecuteGET("http://localhost:5078/D/2024-02-29", (DateTime? x, DateTime? y, int status) => x == new DateTime(2024, 02, 29) && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET("http://localhost:5078/D/2025-02-25T19:25", (DateTime? x, DateTime? y, int status) => x == new DateTime(2025, 02, 25, 19, 25, 0) && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecutePOST("http://localhost:5078/D/2025-02-25|2025-03-25", (DateTime? x, DateTime? y, int status) => x == new DateTime(2025, 02, 25) && y == new DateTime(2025, 03, 25) && status == 200 ? Test.OK : Test.NOK);
            await test.ExecutePUT("http://localhost:5078/D/2025-02-25T19:25", (DateTime? x, DateTime? y, int status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);

            Console.WriteLine("—- /E -----------------------------");
            await test.ExecuteGET<string?>("http://localhost:5078/E/12-bis", (x, y, status) => x == "bisssss" && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET<string?>("http://localhost:5078/E/11-bis", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecuteGET<string?>("http://localhost:5078/E/12-777", (x, y, status) => x == "777" && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET<string?>("http://localhost:5078/E/12-", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePUT<string?>("http://localhost:5078/E/abcd", (x, y, status) => x == "abcd" && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecutePUT<string?>("http://localhost:5078/E/abcd123", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePUT<string?>("http://localhost:5078/E/a", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePUT<string?>("http://localhost:5078/E/123456", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecutePUT<string?>("http://localhost:5078/E/aabbccddeeffgghh", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);

            Console.WriteLine("-- /F ------------------------------------------------------------");
            await test.ExecuteGET<string?>("http://localhost:5078/F/smw@belstu.by", (x, y, status) => x == "smw@belstdsfu.by" && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET<string?>("http://localhost:5078/F/xxx@yyyy.by", (x, y, status) => x == "xxx@yyfasdyy.by" && y == null && status == 200 ? Test.OK : Test.NOK);
            await test.ExecuteGET<string?>("http://localhost:5078/F/xxx@yyyy.ru", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecuteGET<string?>("http://localhost:5078/F/xxxyyyy.by", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
            await test.ExecuteGET<string?>("http://localhost:5078/F/xxx@yyyy", (x, y, status) => x == null && y == null && status == 404 ? Test.OK : Test.NOK);
        }

    }
}