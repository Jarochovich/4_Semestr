﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System;

namespace DAL003
{
    public interface IRepository:IDisposable
    {
        // Патерн Repository
        void         Create(string nameFile); // создание объекта
        void         Update(Celebrity item);  // обновление объекта
        void         Delete(int id);          // удаление объекта по id
        void         Save();                  // сохранение изменений
        void         Dispose();


        // Остальные методы
        string       BasePath { get; }                          // полный директорий для JSON и фотографий
        Celebrity[]  GetAllCelebrities();                       // получить весь список знаменитостей*
        Celebrity?   GetCelebrityById(int id);                  // получить знаменитость по Id*
        Celebrity[]? GetCelebritiesBySurname(string Surname);   // получить знаменитость по фамилии
        string?      GetPhotoPathById(int id);                  // получить путь для GET-запроса к фотографии
    }

    public record Celebrity(int Id, string Firstname, string Surname, string PhotoPath);
    
    public class Repository : IRepository
    {
        public static string JSONFileName;
        public Repository(string nameDirectoryJSON)
        {
            JSONFileName = nameDirectoryJSON;
        }
        public string BasePath 
        {
            get
            {
                return $"./wwwroot/{JSONFileName}/{JSONFileName}.json";
            }
        }

        public void Dispose()
        {
           // Зачем надо?
        }

        public Celebrity[] GetAllCelebrities()
        {
            Celebrity[] celebritys = ReadJSONFile();

            return celebritys;
        }

        public Celebrity[]? GetCelebritiesBySurname(string Surname)
        {
            Celebrity[] celebritys = ReadJSONFile();
            Celebrity[] result = new Celebrity[1];

            foreach (var person in celebritys)
            {
                if (person.Surname == Surname)
                {
                    result[0] = person;
                    return result;
                }
            }

            Celebrity defaultC = new Celebrity(-1, "None", "None", "None");
            result[0] = defaultC;
            return result;
        }

        public Celebrity? GetCelebrityById(int id)
        {
            Celebrity[] celebritys = ReadJSONFile();

            foreach (var person in celebritys)
            {
                if (person.Id == id) return person; 
            }
            return null;
        }

        public string? GetPhotoPathById(int id)
        {
            Celebrity[] celebritys = ReadJSONFile();

            foreach (var person in celebritys)
            {
                if (person.Id == id) return person.PhotoPath;
            }
            return "";
        }

        private Celebrity[] ReadJSONFile()
        {
            using (StreamReader sr = new StreamReader(BasePath))
            {
                string json = sr.ReadToEnd();   // считывает весь текстовый файл
                Celebrity[] celebrities = JsonConvert.DeserializeObject<Celebrity[]>(json);    // десериализация в объект типа Celebrity[]

                return celebrities;
            }
        }

        // Паттерн Repository

        public void Create(string nameFile)
        {
            JSONFileName = nameFile;
        }


        public void Update(Celebrity item)
        {
            var celebrities = new List<Celebrity>(GetAllCelebrities());
            var existingCelebrity = celebrities.Find(c => c.Id == item.Id);

            if (existingCelebrity != null)
            {
                celebrities.Remove(existingCelebrity);
                celebrities.Add(item);
                SaveToJSONFile(celebrities.ToArray());
            }
        }


        public void Delete(int id)
        {
            var celebrities = new List<Celebrity>(GetAllCelebrities());
            var celebrityToRemove = GetCelebrityById(id);

            if (celebrityToRemove != null)
            {
                celebrities.Remove(celebrityToRemove);
                SaveToJSONFile(celebrities.ToArray());
            }
        }


        public void Save()
        {
            // Зачем надо?
        }

        private void SaveToJSONFile(Celebrity[] celebrities)
        {
            using (StreamWriter sw = new StreamWriter(BasePath))
            {
                string json = JsonConvert.SerializeObject(celebrities, Formatting.Indented);
                sw.Write(json);
            }
        }

    }
}
