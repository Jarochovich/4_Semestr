using DAL003;
using Microsoft.Extensions.FileProviders;
using System.Net;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

string path = "Celebrities";
Repository repository = new Repository(path);

app.UseDirectoryBrowser(new DirectoryBrowserOptions
{
    FileProvider = new PhysicalFileProvider(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Celebrities")),
    RequestPath = "/Celebrities/download"
});

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Celebrities")),
    RequestPath = "/Photo"
});

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Celebrities")),
    RequestPath = "/Celebrities/download",
    OnPrepareResponse = ctx =>
    {
        var fileName = WebUtility.UrlEncode(ctx.File.Name);
        ctx.Context.Response.Headers.Append("Content-Disposition", $"attachment; filename=\"{fileName}\"");
    }
});



app.MapGet("/Celebrities", () => repository.GetAllCelebrities());
app.MapGet("/Celebrities/{id:int}", (int id) => repository.GetCelebrityById(id));
app.MapGet("/Celebrities/BySurname/{surname}", (string surname) => repository.GetCelebritiesBySurname(surname));
app.MapGet("/Celebrities/PhotoPathId/{id:int}", (int id) => repository.GetPhotoPathById(id));
app.MapGet("/", () => "Hello World!");

app.Run();