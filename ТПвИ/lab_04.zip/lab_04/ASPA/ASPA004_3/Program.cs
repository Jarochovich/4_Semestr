using DAL004;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.Extensions.FileProviders;
using System.Net;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

string path = "Celebrities";
Repository repository = new Repository(path);

app.UseExceptionHandler("/Celebrities/Error");

app.MapGet("/Celebrities", () => repository.GetAllCelebrities());

app.MapGet("/Celebrities/{id:int}", (int id) =>
{
    Celebrity? celebrity = repository?.GetCelebrityById(id);
    if (celebrity == null) throw new FoundByIdException($"Not found celebrity Id = {id}");
    return celebrity;
});
app.MapPost("/Celebrities", (Celebrity celebrity) =>
{
    bool foundPhotoPath = false;
    
    //
    DirectoryInfo directoryInfo = new DirectoryInfo("C:\\Users\\yarok\\Desktop\\������\\4_���_����\\����\\lab_04\\ASPA\\ASPA004_3\\Celebrities\\Photo");
    
    foreach (var file in directoryInfo.GetFiles())
    {
        if (celebrity.PhotoPath == $"/Photo/{file.Name}") foundPhotoPath = true;
    }
    //

    int? id = repository.addCelebrity(celebrity);
    if (id == null) throw new AddCelebrityException("/Celebrities error, id == null");
    if (repository.SaveChanges() <= 0) throw new SaveException("/Celerities error, SaveChanges() <= 0");

    if (!foundPhotoPath) throw new AddCelebrityException($"Could not fond file: {celebrity.PhotoPath}");

    return new Celebrity((int)id, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
});

app.MapFallback((HttpContext ctx) => Results.NotFound(new { error = $"path {ctx.Request.Path} not supported " }));

app.Map("/Celebrities/Error", (HttpContext ctx) =>
{
    Exception? ex = ctx.Features.Get<IExceptionHandlerFeature>()?.Error;
    IResult rc = Results.Problem(detail: "Panic", instance: app.Environment.EnvironmentName, title: "ASPA004", statusCode: 500);
    if (ex != null)
    {
        if (ex is UpdCelebrityException) rc = Results.Problem(title: "ASPA004/UpdCelebrityException", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is DeleteCelebrityException) rc = Results.Problem(title: "ASPA004/DeleteCelebrityException", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is FileNotFoundException) rc = Results.Problem(title: "ASPA004/FileNotFoundException", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is FoundByIdException) rc = Results.Problem(title: "ASPA004/FoundByIdException", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 404);
        if (ex is BadHttpRequestException) rc = Results.Problem(title: "ASPA004/BadHttpRequestException", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 404);
        if (ex is SaveException) rc = Results.Problem(title: "ASPA004/SaveChanges", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
        if (ex is AddCelebrityException) rc = Results.Problem(title: "ASPA004/addCelebrity", detail: ex.Message, instance: app.Environment.EnvironmentName, statusCode: 500);
    }
    return rc;
});

app.MapDelete("/Celebrities/{id:int}", (int id) =>
{
    if (repository.GetCelebrityById(id) == null) throw new DeleteCelebrityException($"DELETE /Celebrities error, Id = {id}");
    repository.deleteCelebtityById(id);
    return $"Celebrity with Id = {id} deleted";
});

app.MapPut("/Celebrities/{id:int}", (int id, Celebrity celebrity) =>
{
    int? newId = null;
    if ((newId = repository.updCelebrityById(id, celebrity)) == null) throw new UpdCelebrityException($"put error: {id}");
    return new Celebrity((int)newId, celebrity.Firstname, celebrity.Surname, celebrity.PhotoPath);
});

app.Run();

public class UpdCelebrityException : Exception { public UpdCelebrityException(string message) : base($"UpdCelebrityException error {message}") { } };
public class DeleteCelebrityException : Exception { public DeleteCelebrityException(string message) : base($"Delete by Id: {message}") { } };
public class FoundByIdException : Exception { public FoundByIdException(object message) : base($"{message}") { } };
public class SaveException : Exception { public SaveException(string message) : base($"SaveChanges error: {message}") { } };
public class AddCelebrityException : Exception { public AddCelebrityException(string message) : base($"{message}") { } };