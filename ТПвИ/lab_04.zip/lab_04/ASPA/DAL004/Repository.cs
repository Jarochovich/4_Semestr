﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System;
using System.Xml;

namespace DAL004
{
    public interface IRepository : IDisposable
    {
        string BasePath { get; }                          // полный директорий для JSON и фотографий
        Celebrity[] GetAllCelebrities();                       // получить весь список знаменитостей*
        Celebrity? GetCelebrityById(int id);                  // получить знаменитость по Id*
        Celebrity[]? GetCelebritiesBySurname(string Surname);   // получить знаменитость по фамилии
        string? GetPhotoPathById(int id);                  // получить путь для GET-запроса к фотографии
        int? addCelebrity(Celebrity celebrity);         // добавить знаменитость,  =Id новой знаменитости
        bool deleteCelebtityById(int id);               // удалить знаменитость по Id,  =true - успех
        int? updCelebrityById(int id, Celebrity celebrity);     // изменить знаменитость по Id,  =Id - новый Id - успех
        int SaveChanges();                          // сохранить изменения в JSON,  =количество изменений
    }

    public record Celebrity(int Id, string Firstname, string Surname, string PhotoPath);

    public class Repository : IRepository
    {
        public static string JSONFileName;
        public Repository(string nameDirectoryJSON)
        {
            JSONFileName = nameDirectoryJSON;
        }
        public string BasePath
        {
            get
            {
                return $"./{JSONFileName}/{JSONFileName}.json";
            }
        }


        public Celebrity[] GetAllCelebrities()
        {
            Celebrity[] celebritys = ReadJSONFile();

            return celebritys;
        }

        public Celebrity[]? GetCelebritiesBySurname(string Surname)
        {
            Celebrity[] celebritys = ReadJSONFile();
            Celebrity[] result = new Celebrity[1];

            foreach (var person in celebritys)
            {
                if (person.Surname == Surname)
                {
                    result[0] = person;
                    return result;
                }
            }

            return null;
        }

        public Celebrity? GetCelebrityById(int id)
        {
            Celebrity[] celebritys = ReadJSONFile();

            foreach (var person in celebritys)
            {
                if (person.Id == id) return person;
            }
            return null;
        }

        public string? GetPhotoPathById(int id)
        {
            Celebrity[] celebritys = ReadJSONFile();

            foreach (var person in celebritys)
            {
                if (person.Id == id) return person.PhotoPath;
            }
            return "";
        }

        private Celebrity[] ReadJSONFile()
        {
            using (StreamReader sr = new StreamReader(BasePath))
            {
                string json = sr.ReadToEnd();   // считывает весь текстовый файл
                Celebrity[] celebrities = JsonConvert.DeserializeObject<Celebrity[]>(json);    // десериализация в объект типа Celebrity[]

                return celebrities;
            }
        }

        private void SaveToJSONFile(Celebrity[] celebrities)
        {
            using (StreamWriter sw = new StreamWriter(BasePath))
            {
                string json = JsonConvert.SerializeObject(celebrities, Newtonsoft.Json.Formatting.Indented);
                sw.Write(json);
            }
        }

        // Добавленные методы в DAL004

        public int? addCelebrity(Celebrity celebrity)
        {
            var celebrities = new List<Celebrity>(GetAllCelebrities());

            // Если переданный Id равен 0, назначаем новый Id как последний существующий Id + 1
            if (celebrity.Id == 0)
            {
                int maxId = celebrities.Count > 0 ? celebrities.Max(c => c.Id) : 0; // Если список пустой, Id начинается с 1
                celebrity = celebrity with { Id = maxId + 1 };
            }
            // Проверяем на уникальность нового Id
            if (celebrities.Exists(c => c.Id == celebrity.Id))
            {
                return null; // Если Id уже существует, добавление невозможно
            }
            celebrities.Add(celebrity);
            SaveToJSONFile(celebrities.ToArray());
            return celebrity.Id; // Возвращаем Id добавленной знаменитости
        }


        public bool deleteCelebtityById(int id)
        {
            var celebrities = new List<Celebrity>(GetAllCelebrities());
            var celebrityToRemove = celebrities.Find(c => c.Id == id);

            if (celebrityToRemove != null)
            {
                celebrities.Remove(celebrityToRemove);
                SaveToJSONFile(celebrities.ToArray());
                return true; // Успешное удаление
            }
            return false; // Знаменитость с указанным Id не найдена
        }

        public int? updCelebrityById(int id, Celebrity celebrity)
        {
            var celebrities = new List<Celebrity>(GetAllCelebrities());
            var existingCelebrity = celebrities.Find(c => c.Id == id);

            if (existingCelebrity != null)
            {
                celebrities.Remove(existingCelebrity);
                celebrity = celebrity with { Id = id }; // Обновляем Id у переданного объекта
                celebrities.Add(celebrity);
                SaveToJSONFile(celebrities.ToArray());
                return celebrity.Id; // Возвращаем обновленный Id
            }
            return null; // Знаменитость с указанным Id не найдена
        }

        public int SaveChanges()
        {
            var celebrities = GetAllCelebrities();
            SaveToJSONFile(celebrities);
            return celebrities.Length; // Возвращаем количество сохраненных объектов
        }

        public void Dispose()
        {
            // Освобождение ресурсов, если нужно
            GC.SuppressFinalize(this);
        }

    }

}