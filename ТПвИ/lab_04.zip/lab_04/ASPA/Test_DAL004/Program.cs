﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL004
{
    class Programm
    {
        static void Main(string[] args)
        {
            string path = "Celebrities";
            Repository repository = new Repository(path);

            void print(string label)
            {
                Console.WriteLine("------" + label + "------");

                foreach (Celebrity celebrity in repository.GetAllCelebrities())
                {
                    Console.WriteLine($"Id = {celebrity.Id}, Firstname = {celebrity.Firstname}, " +
                        $"Surname = {celebrity.Surname}, PhotoPath = {celebrity.PhotoPath}");
                }
            }

            print("Start");

            int? testDel1 = repository.addCelebrity(new Celebrity(0, "TestDel1", "TestDel1", "Photo/TestDel1.jpg"));
            int? testDel2 = repository.addCelebrity(new Celebrity(0, "TestDel2", "TestDel2", "Photo/TestDel2.jpg"));
            int? testUpd1 = repository.addCelebrity(new Celebrity(0, "TestUpd1", "TestUpd1", "Photo/TestUpd1.jpg"));
            int? testUpd2 = repository.addCelebrity(new Celebrity(0, "TestUpd2", "TestUpd2", "Photo/TestUpd2.jpg"));
            repository.SaveChanges();
            print("add 4");

            if (testDel1 != null)
                if (repository.deleteCelebtityById((int)testDel1)) Console.WriteLine($" delete {testDel1} "); 
                else Console.WriteLine($"delete {testDel1} error");
            if (testDel2 != null)
                if (repository.deleteCelebtityById((int)testDel2)) Console.WriteLine($" delete {testDel2} "); 
                else Console.WriteLine($"delete {testDel2} error");
            if (repository.deleteCelebtityById(1000)) Console.WriteLine($" delete {1000} "); 
            else Console.WriteLine($"delete {1000} error");
            repository.SaveChanges();
            print("del 2");


            if (testUpd1 != null)
                if (repository.updCelebrityById((int)testUpd1, new Celebrity(0, "Updated1", "Updated1", "Photo/Updated1.jpg")).HasValue) Console.WriteLine($" update {testUpd1} ");
                else Console.WriteLine($"update {testUpd1} error");
            if (testUpd2 != null)
                if (repository.updCelebrityById((int)testUpd2, new Celebrity(0, "Updated2", "Updated2", "Photo/Updated2.jpg")).HasValue) Console.WriteLine($" update {testUpd2} ");
                else Console.WriteLine($"update {testUpd2} error");
            if (repository.updCelebrityById(1000, new Celebrity(0, "Updated1000", "Updated1000", "Photo/Updated1000.jpg")).HasValue) Console.WriteLine($" update {1000} ");
            repository.SaveChanges();
            print("upd 2");




            //Celebrity? celebrity1 = repository.GetCelebrityById(1);
            //if (celebrity1 != null)
            //{
            //    Console.WriteLine($"Id = {celebrity1.Id}, Firstname = {celebrity1.Firstname}, " +
            //        $"Surname = {celebrity1.Surname}, PhotoPath = {celebrity1.PhotoPath}");
            //}
            //Celebrity? celebrity3 = repository.GetCelebrityById(3);
            //if (celebrity3 != null)
            //{
            //    Console.WriteLine($"Id = {celebrity3.Id}, Firstname = {celebrity3.Firstname}, " +
            //        $"Surname = {celebrity3.Surname}, PhotoPath = {celebrity3.PhotoPath}");
            //}
            //Celebrity? celebrity7 = repository.GetCelebrityById(7);
            //if (celebrity7 != null)
            //{
            //    Console.WriteLine($"Id = {celebrity7.Id}, Firstname = {celebrity7.Firstname}, " +
            //        $"Surname = {celebrity7.Surname}, PhotoPath = {celebrity7.PhotoPath}");
            //}
            //Celebrity? celebrity222 = repository.GetCelebrityById(222);
            //if (celebrity222 != null)
            //{
            //    Console.WriteLine($"Id = {celebrity222.Id}, Firstname = {celebrity222.Firstname}, " +
            //        $"Surname = {celebrity222.Surname}, PhotoPath = {celebrity222.PhotoPath}");
            //}
            //else Console.WriteLine($"Not found 222");

            //foreach (Celebrity? celebrity in repository.GetCelebritiesBySurname("Chomsky"))
            //{
            //    Console.WriteLine($"Id = {celebrity.Id}, Firstname = {celebrity.Firstname}, " +
            //        $"Surname = {celebrity.Surname}, PhotoPath = {celebrity.PhotoPath}");
            //}
            //foreach (Celebrity? celebrity in repository.GetCelebritiesBySurname("Knuth"))
            //{
            //    Console.WriteLine($"Id = {celebrity.Id}, Firstname = {celebrity.Firstname}, " +
            //        $"Surname = {celebrity.Surname}, PhotoPath = {celebrity.PhotoPath}");
            //}
            //foreach (Celebrity? celebrity in repository.GetCelebritiesBySurname("XXXX"))
            //{
            //    Console.WriteLine($"Id = {celebrity.Id}, Firstname = {celebrity.Firstname}, " +
            //        $"Surname = {celebrity.Surname}, PhotoPath = {celebrity.PhotoPath}");
            //}

            //Console.WriteLine($"PhotoPath = {repository.GetPhotoPathById(4)}");
            //Console.WriteLine($"PhotoPath = {repository.GetPhotoPathById(6)}");
            //Console.WriteLine($"PhotoPath = {repository.GetPhotoPathById(222)}");
        }
    }
}
