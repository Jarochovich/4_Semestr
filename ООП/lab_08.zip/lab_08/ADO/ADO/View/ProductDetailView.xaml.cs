﻿using ADO.Model;
using ADO.ViewModel;
using System.Windows;

namespace ADO.View
{
    /// <summary>
    /// Логика взаимодействия для ProductDetailView.xaml
    /// </summary>
    public partial class ProductDetailView : Window
    {
        public ProductDetailView(ProductDetailViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }
    }
}
