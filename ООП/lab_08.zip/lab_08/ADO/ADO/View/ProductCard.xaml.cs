﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ADO.View
{
    /// <summary>
    /// Логика взаимодействия для ProductCard.xaml
    /// </summary>
    public partial class ProductCard : UserControl
    {
        public ProductCard()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        public string ProductName
        {
            get => (string)GetValue(ProductNameProperty);
            set => SetValue(ProductNameProperty, value);
        }

        public static readonly DependencyProperty ProductNameProperty =
            DependencyProperty.Register("ProductName", typeof(string), typeof(ProductCard), new PropertyMetadata("Товар"));

        public string ProductPrice
        {
            get => (string)GetValue(ProductPriceProperty);
            set => SetValue(ProductPriceProperty, value);
        }

        public static readonly DependencyProperty ProductPriceProperty =
            DependencyProperty.Register("ProductPrice", typeof(string), typeof(ProductCard), new PropertyMetadata("0 BYN"));
    }
}
