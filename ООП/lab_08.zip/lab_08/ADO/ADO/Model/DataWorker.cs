﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using ADO.Helpers;
using System.Diagnostics;
using System.Windows;
using static ADO.Model.Purchase;
using System.Globalization;
using Microsoft.Data.SqlClient;
using System.Configuration;

namespace ADO.Model
{
   
    public static class DataWorker
    {
        public static string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;

        // Получить все категории
        public static List<Category> GetAllCategories()
        {
            var categories = new List<Category>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("SELECT Id, Name FROM Categories", connection);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            categories.Add(new Category
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1)
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении категорий: {ex.Message}");
                }
            }

            return categories;
        }

        // Получить всех производителей
        public static List<Manufacturer> GetAllManufacturers()
        {
            var manufacturers = new List<Manufacturer>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("SELECT Id, Name FROM Manufacturers", connection);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            manufacturers.Add(new Manufacturer
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                               
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении производителей: {ex.Message}");
                }
            }

            return manufacturers;
        }

        public static User GetUserByCredentials(string login, string password)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "SELECT Id, Login, Balance FROM Users WHERE Login = @login AND Password = @password",
                    connection);

                command.Parameters.AddWithValue("@login", login);
                command.Parameters.AddWithValue("@password", password);

                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new User
                        {
                            Id = reader.GetInt32(0),
                            Login = reader.GetString(1),
                            Balance = reader.GetDecimal(2)
                        };
                    }
                }
            }

            return null;
        }

        // Получить все продукты с производителями
        public static List<Product> GetAllProducts()
        {
            var products = new List<Product>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                SELECT p.Id, p.Name, p.Price, p.Quantity, p.CategoryId, p.ManufacturerId, 
                       m.Name AS ManufacturerName
                FROM Products p
                JOIN Manufacturers m ON p.ManufacturerId = m.Id", connection);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            products.Add(new Product
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2),
                                Quantity = reader.GetInt32(3),
                                CategoryId = reader.GetInt32(4),
                                ManufacturerId = reader.GetInt32(5),
                                Manufacturer = new Manufacturer
                                {
                                    Id = reader.GetInt32(5),
                                    Name = reader.GetString(6),
                                    //Country = reader.IsDBNull(7) ? null : reader.GetString(7)
                                }
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении продуктов: {ex.Message}");
                }
            }

            return products;
        }

        // Получить отзывы
        public static List<Review> GetAllReviews()
        {
            var reviews = new List<Review>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("SELECT Id, ProductId, UserId, Rating, Comment, DateCreated FROM Reviews", connection);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            reviews.Add(new Review
                            {
                                Id = reader.GetInt32(0),
                                ProductId = reader.GetInt32(1),
                                UserId = reader.GetInt32(2),
                                Rating = reader.GetInt32(3),
                                Comment = reader.IsDBNull(4) ? null : reader.GetString(4),                          
                                DateCreated = reader.GetDateTime(5)
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении отзывов: {ex.Message}");
                }
            }

            return reviews;
        }

        // Списание товара
        public static int DecreaseProductQuantity(int productId, int count)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "UPDATE Products SET Quantity = Quantity - @count WHERE Id = @productId AND Quantity >= @count;" +
                    "SELECT @@ROWCOUNT;", connection);

                command.Parameters.AddWithValue("@productId", productId);
                command.Parameters.AddWithValue("@count", count);

                try
                {
                    connection.Open();
                    return (int)command.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при списании товара: {ex.Message}");
                    return 0;
                }
            }
        }

        // Обновление пользователя
        public static void UpdateUser(User user)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "UPDATE Users SET Login = @login, PhoneNumber = @phone WHERE Id = @id", connection);

                command.Parameters.AddWithValue("@id", user.Id);
                command.Parameters.AddWithValue("@login", user.Login);
                command.Parameters.AddWithValue("@phone", (object)user.PhoneNumber ?? DBNull.Value);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при обновлении пользователя: {ex.Message}");
                }
            }
        }

        // Возврат на склад
        public static bool CancelPurchase(int purchaseId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var transaction = connection.BeginTransaction();

                try
                {
                    // 1. Получаем информацию о покупке
                    var getCommand = new SqlCommand(
                        "SELECT ProductId, Quantity FROM Purchases WHERE Id = @purchaseId AND Status = 'Pending'",
                        connection, transaction);
                    getCommand.Parameters.AddWithValue("@purchaseId", purchaseId);

                    connection.Open();
                    using (var reader = getCommand.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            transaction.Rollback();
                            return false;
                        }

                        int productId = reader.GetInt32(0);
                        int quantity = reader.GetInt32(1);

                        reader.Close();

                        // 2. Возвращаем товар на склад
                        var updateCommand = new SqlCommand(
                            "UPDATE Products SET Quantity = Quantity + @quantity WHERE Id = @productId",
                            connection, transaction);
                        updateCommand.Parameters.AddWithValue("@productId", productId);
                        updateCommand.Parameters.AddWithValue("@quantity", quantity);
                        updateCommand.ExecuteNonQuery();

                        // 3. Отменяем покупку
                        var cancelCommand = new SqlCommand(
                            "UPDATE Purchases SET Status = 'Cancelled' WHERE Id = @purchaseId",
                            connection, transaction);
                        cancelCommand.Parameters.AddWithValue("@purchaseId", purchaseId);
                        cancelCommand.ExecuteNonQuery();

                        transaction.Commit();
                        return true;
                    }
                }
                catch
                {
                    transaction.Rollback();
                    return false;
                }
            }
        }

        // Получить продукты по категории
        public static List<Product> GetProductsByCategory(int categoryId)
        {
            var products = new List<Product>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                SELECT p.Id, p.Name, p.Price, p.Quantity, p.ManufacturerId, m.Name AS ManufacturerName
                FROM Products p
                JOIN Manufacturers m ON p.ManufacturerId = m.Id
                WHERE p.CategoryId = @categoryId", connection);

                command.Parameters.AddWithValue("@categoryId", categoryId);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            products.Add(new Product
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2),
                                Quantity = reader.GetInt32(3),
                                ManufacturerId = reader.GetInt32(4),
                                Manufacturer = new Manufacturer
                                {
                                    Id = reader.GetInt32(4),
                                    Name = reader.GetString(5)
                                }
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении продуктов по категории: {ex.Message}");
                }
            }

            return products;
        }

        // Получить отзывы по продукту
        public static List<Review> GetReviewsByProductId(int productId)
        {
            var reviews = new List<Review>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                SELECT r.Id, r.UserId, u.Login, r.Rating, r.Comment, r.DateCreated
                FROM Reviews r
                JOIN Users u ON r.UserId = u.Id
                WHERE r.ProductId = @productId", connection);

                command.Parameters.AddWithValue("@productId", productId);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            reviews.Add(new Review
                            {
                                Id = reader.GetInt32(0),
                                UserId = reader.GetInt32(1),
                                User = new User { Login = reader.GetString(2) },
                                Rating = reader.GetInt32(3),
                                Comment = reader.IsDBNull(4) ? null : reader.GetString(4),
                                DateCreated = reader.GetDateTime(5)
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении отзывов: {ex.Message}");
                }
            }

            return reviews;
        }

        // Получить всех пользователей
        public static List<User> GetAllUsers()
        {
            var users = new List<User>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand("SELECT Id, Login, PhoneNumber FROM Users", connection);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            users.Add(new User
                            {
                                Id = reader.GetInt32(0),
                                Login = reader.GetString(1),
                                PhoneNumber = reader.IsDBNull(2) ? null : reader.GetString(2),
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении пользователей: {ex.Message}");
                }
            }

            return users;
        }

        // Получить продукт по ID
        public static Product GetProductById(int productId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                SELECT p.Id, p.Name, p.Price, p.Quantity, p.CategoryId, p.ManufacturerId, 
                       m.Name AS ManufacturerName
                FROM Products p
                JOIN Manufacturers m ON p.ManufacturerId = m.Id
                WHERE p.Id = @productId", connection);

                command.Parameters.AddWithValue("@productId", productId);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Product
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2),
                                Quantity = reader.GetInt32(3),
                                CategoryId = reader.GetInt32(4),
                                ManufacturerId = reader.GetInt32(5),
                                Manufacturer = new Manufacturer
                                {
                                    Id = reader.GetInt32(5),
                                    Name = reader.GetString(6)
                                    //Country = reader.IsDBNull(7) ? null : reader.GetString(7)
                                }
                            };
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении продукта: {ex.Message}");
                }
            }

            return null;
        }

        // Проверка на администратора
        public static bool IsAdmin(string login, string password)
        {
            if (!login.Equals("admin", StringComparison.OrdinalIgnoreCase))
                return false;

            using (var connection = new SqlConnection(connectionString))
            {
                // Проверяем пароль для пользователя admin
                var command = new SqlCommand(
                    "SELECT COUNT(1) FROM Users WHERE Login = @login AND Password = @password",
                    connection);

                command.Parameters.AddWithValue("@login", login);
                command.Parameters.AddWithValue("@password", SimpleHash(password));

                try
                {
                    connection.Open();
                    return (int)command.ExecuteScalar() > 0;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при проверке администратора: {ex.Message}");
                    return false;
                }
            }
        }

        // Получить ожидающие покупки пользователя
        public static List<Purchase> GetPendingPurchases(int userId)
        {
            var purchases = new List<Purchase>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                SELECT p.Id, p.ProductId, pr.Name AS ProductName, p.Quantity, p.PurchaseDate
                FROM Purchases p
                JOIN Products pr ON p.ProductId = pr.Id
                WHERE p.UserId = @userId AND p.Status = 'Pending'", connection);

                command.Parameters.AddWithValue("@userId", userId);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            purchases.Add(new Purchase
                            {
                                Id = reader.GetInt32(0),
                                ProductId = reader.GetInt32(1),
                                Product = new Product { Name = reader.GetString(2) },
                                Quantity = reader.GetInt32(3),
                                PurchaseDate = reader.GetDateTime(4)
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении покупок: {ex.Message}");
                }
            }

            return purchases;
        }

        // Получить подтвержденные покупки пользователя
        public static List<Product> GetConfirmedPurchases(int userId)
        {
            var products = new List<Product>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                SELECT pr.Id, pr.Name, pr.Price, pu.Quantity, pu.PurchaseDate
                FROM Purchases pu
                JOIN Products pr ON pu.ProductId = pr.Id
                WHERE pu.UserId = @userId AND pu.Status = 'Confirmed'", connection);

                command.Parameters.AddWithValue("@userId", userId);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            products.Add(new Product
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2),
                                Quantity = reader.GetInt32(3),
                                // Дополнительное поле для отображения даты покупки
                                //d = reader.GetDateTime(4)
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении покупок: {ex.Message}");
                }
            }

            return products;
        }

        // Получить все заказы
        public static List<Purchase> GetAllPurchases()
        {
            var purchases = new List<Purchase>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                SELECT p.Id, p.UserId, u.Login, p.ProductId, pr.Name AS ProductName, 
                       p.Quantity, p.PurchaseDate, p.Status
                FROM Purchases p
                JOIN Users u ON p.UserId = u.Id
                JOIN Products pr ON p.ProductId = pr.Id
                ORDER BY p.PurchaseDate DESC", connection);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            purchases.Add(new Purchase
                            {
                                Id = reader.GetInt32(0),
                                UserId = reader.GetInt32(1),
                                User = new User { Login = reader.GetString(2) },
                                ProductId = reader.GetInt32(3),
                                Product = new Product { Name = reader.GetString(4) },
                                Quantity = reader.GetInt32(5),
                                PurchaseDate = reader.GetDateTime(6),
                                Status = Enum.Parse<Purchase.PurchaseStatus>(reader.GetString(7))
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении заказов: {ex.Message}");
                }
            }

            return purchases;
        }

        // Подтвердить покупку
        public static bool ConfirmPurchase(int purchaseId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "UPDATE Purchases SET Status = 'Confirmed' WHERE Id = @purchaseId AND Status = 'Pending'",
                    connection);

                command.Parameters.AddWithValue("@purchaseId", purchaseId);

                try
                {
                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
                catch
                {
                    return false;
                }
            }
        }

        // Получить подтвержденные покупки пользователя
        public static List<Purchase> GetConfirmedPurchasesByUserId(int userId)
        {
            var purchases = new List<Purchase>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                SELECT p.Id, p.ProductId, pr.Name AS ProductName, p.Quantity, p.PurchaseDate
                FROM Purchases p
                JOIN Products pr ON p.ProductId = pr.Id
                WHERE p.UserId = @userId AND p.Status = 'Confirmed'", connection);

                command.Parameters.AddWithValue("@userId", userId);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            purchases.Add(new Purchase
                            {
                                Id = reader.GetInt32(0),
                                ProductId = reader.GetInt32(1),
                                Product = new Product { Name = reader.GetString(2) },
                                Quantity = reader.GetInt32(3),
                                PurchaseDate = reader.GetDateTime(4)
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при получении покупок: {ex.Message}");
                }
            }

            return purchases;
        }

        // Сохранить ожидающую покупку
        public static Purchase SavePendingPurchase(Purchase purchase)
        {
            // Сначала проверяем существование пользователя
            if (!UserExists(purchase.UserId))
            {
                MessageBox.Show("Ошибка: указанный пользователь не существует");
                return null;
            }

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
            INSERT INTO Purchases (UserId, ProductId, Quantity, PurchaseDate, Status)
            OUTPUT INSERTED.*
            VALUES (@userId, @productId, @quantity, @purchaseDate, 0)", connection);

                command.Parameters.AddWithValue("@userId", purchase.UserId);
                command.Parameters.AddWithValue("@productId", purchase.ProductId);
                command.Parameters.AddWithValue("@quantity", purchase.Quantity);
                command.Parameters.AddWithValue("@purchaseDate", DateTime.Now);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new Purchase
                            {
                                Id = reader.GetInt32(0),
                                UserId = reader.GetInt32(1),
                                ProductId = reader.GetInt32(2),
                                Quantity = reader.GetInt32(3),
                                PurchaseDate = reader.GetDateTime(4),
                                Status = (Purchase.PurchaseStatus)reader.GetInt32(5)
                            };
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении покупки: {ex.Message}");
                }
            }

            return null;
        }


        // Метод проверки существования пользователя
        private static bool UserExists(int userId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "SELECT COUNT(1) FROM Users WHERE Id = @userId",
                    connection);

                command.Parameters.AddWithValue("@userId", userId);

                connection.Open();
                return (int)command.ExecuteScalar() > 0;
            }
        }


        // Проверить пользователя
        public static bool GetUser(string login, string password)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Получаем сохраненный хеш из БД
                    var command = new SqlCommand(
                        "SELECT Password FROM Users WHERE Login = @login",
                        connection);
                    command.Parameters.AddWithValue("@login", login);

                    var savedHash = command.ExecuteScalar()?.ToString();
                    if (string.IsNullOrEmpty(savedHash)) return false;

                    // Хешируем введенный пароль и сравниваем
                    string inputHash = SimpleHash(password);
                    return inputHash == savedHash;
                }
                catch
                {
                    return false;
                }
            }
        }

        // Получить пользователя по логину
        public static User GetUserByLogin(string login)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    var command = new SqlCommand(
                        "SELECT Login, Balance, PhoneNumber FROM Users WHERE Login = @login",
                        connection);
                    command.Parameters.AddWithValue("@login", login);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Создаем объект пользователя только с доступными полями
                            return new User
                            {
                                Login = reader["Login"].ToString(),
                                Balance = Convert.ToDecimal(reader["Balance"]),
                                PhoneNumber = reader["PhoneNumber"]?.ToString()
                            };
                        }
                        return null; // Пользователь не найден
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка в GetUserByLogin: {ex.Message}");
                    return null;
                }
            }
        }

        // Получить купленные продукты
        public static List<Product> GetPurchasedProducts(int userId)
        {
            var products = new List<Product>();

            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(@"
                    SELECT p.Id, p.Name, p.Price, p.Description, p.ImageData, pu.Quantity AS PurchaseQuantity
                    FROM Purchases pu
                    JOIN Products p ON pu.ProductId = p.Id
                    WHERE pu.UserId = @userId AND pu.Status = 1", connection); // Используем числовой код статуса

                command.Parameters.AddWithValue("@userId", userId);

                try
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var product = new Product
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2),
                                Description = reader.GetString(3),
                                ImageData = reader.IsDBNull(4) ? null : (byte[])reader[4],
                                PurchaseQuantity = reader.GetInt32(5)
                            };
                            products.Add(product);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"Ошибка при загрузке покупок: {ex}");
                    throw;
                }
            }

            return products;
        }

        // Проверить, оставлял ли пользователь отзыв на товар
        public static bool UserHasReviewedProduct(int userId, int productId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "SELECT COUNT(1) FROM Reviews WHERE UserId = @userId AND ProductId = @productId",
                    connection);

                command.Parameters.AddWithValue("@userId", userId);
                command.Parameters.AddWithValue("@productId", productId);

                try
                {
                    connection.Open();
                    return (int)command.ExecuteScalar() > 0;
                }
                catch
                {
                    return false;
                }
            }
        }

        // Получить количество товара
        public static int GetProductQuantity(int productId)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "SELECT Quantity FROM Products WHERE Id = @productId",
                    connection);

                command.Parameters.AddWithValue("@productId", productId);

                try
                {
                    connection.Open();
                    var result = command.ExecuteScalar();
                    return result != DBNull.Value ? Convert.ToInt32(result) : 0;
                }
                catch
                {
                    return 0;
                }
            }
        }

        // Добавить новый продукт
        public static string CreateProduct(Category category, Manufacturer manufacturer,
            string name, int quantity, decimal price, string description, byte[] imageData = null)
        {
            if (category == null)
                return "Не указана категория продукта";

            if (manufacturer == null)
                return "Не указан производитель";

            if (string.IsNullOrWhiteSpace(name))
                return "Не указано название продукта";

            if (name.Length < 2)
                return "Название продукта должно содержать не менее 2 символов";

            if (price <= 0)
                return "Цена должна быть больше нуля";

            if (quantity <= 0)
                return "Количество товаров должно быть больше нуля";

            if (string.IsNullOrWhiteSpace(description))
                return "Не указано описание продукта";

            if (description.Length < 10)
                return "Описание товара должно содержать не менее 10 символов";

            if (imageData == null)
                return "Не добавлено изображение товара";

            using (var connection = new SqlConnection(connectionString))
            {
                // Проверка на существование продукта
                var checkCommand = new SqlCommand(
                    "SELECT COUNT(1) FROM Products WHERE Name = @name AND Price = @price AND CategoryId = @categoryId",
                    connection);

                checkCommand.Parameters.AddWithValue("@name", name);
                checkCommand.Parameters.AddWithValue("@price", price);
                checkCommand.Parameters.AddWithValue("@categoryId", category.Id);

                try
                {
                    connection.Open();
                    bool exists = (int)checkCommand.ExecuteScalar() > 0;
                    if (exists)
                        return "Продукт уже существует";

                    // Добавление нового продукта
                    var insertCommand = new SqlCommand(@"
                    INSERT INTO Products (CategoryId, ManufacturerId, Name, Quantity, Price, Description, ImageData)
                    VALUES (@categoryId, @manufacturerId, @name, @quantity, @price, @description, @imageData)",
                        connection);

                    insertCommand.Parameters.AddWithValue("@categoryId", category.Id);
                    insertCommand.Parameters.AddWithValue("@manufacturerId", manufacturer.Id);
                    insertCommand.Parameters.AddWithValue("@name", name.Trim());
                    insertCommand.Parameters.AddWithValue("@quantity", quantity);
                    insertCommand.Parameters.AddWithValue("@price", price);
                    insertCommand.Parameters.AddWithValue("@description", description.Trim());
                    insertCommand.Parameters.AddWithValue("@imageData", imageData != null ? (object)imageData : DBNull.Value);

                    int rowsAffected = insertCommand.ExecuteNonQuery();
                    return rowsAffected > 0 ? "Продукт успешно добавлен!" : "Не удалось добавить продукт";
                }
                catch (Exception ex)
                {
                    return $"Ошибка при добавлении продукта: {ex.Message}";
                }
            }
        }

        // Пополнить баланс пользователя
        public static bool UpdateUserBalance(int userId, decimal amount)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "UPDATE Users SET Balance = Balance + @amount WHERE Id = @userId",
                    connection);

                command.Parameters.AddWithValue("@userId", userId);
                command.Parameters.AddWithValue("@amount", amount);

                try
                {
                    connection.Open();
                    return command.ExecuteNonQuery() > 0;
                }
                catch
                {
                    return false;
                }
            }
        }

        // Добавить пользователя (асинхронная версия)
        public static async Task<bool> CreateUserAsync(string login, string password, string phone)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                // Проверка на существование пользователя
                var checkCommand = new SqlCommand(
                    "SELECT COUNT(1) FROM Users WHERE Login = @login",
                    connection);
                checkCommand.Parameters.AddWithValue("@login", login);

                try
                {
                    await connection.OpenAsync();
                    var exists = (int)await checkCommand.ExecuteScalarAsync() > 0;
                    if (exists) return false;

                    // Упрощенное хеширование (без соли, так как нет отдельного поля)
                    string hashedPassword = SimpleHash(password);

                    // Проверка длины пароля
                    if (hashedPassword.Length > 100)
                    {
                        Console.WriteLine("Хеш пароля слишком длинный для поля Password");
                        return false;
                    }

                    // Добавление пользователя (соответствует структуре таблицы)
                    var insertCommand = new SqlCommand(@"
                INSERT INTO Users (Login, Password, PhoneNumber, Balance)
                VALUES (@login, @password, @phone, 0)",
                        connection);

                    insertCommand.Parameters.AddWithValue("@login", login);
                    insertCommand.Parameters.AddWithValue("@password", hashedPassword);
                    insertCommand.Parameters.AddWithValue("@phone", string.IsNullOrEmpty(phone) ? DBNull.Value : (object)phone);

                    return await insertCommand.ExecuteNonQueryAsync() > 0;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка при создании пользователя: {ex.Message}");
                    return false;
                }
            }
        }

        // Простое хеширование без соли
        private static string SimpleHash(string input)
        {
            using (var sha256 = System.Security.Cryptography.SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                return Convert.ToBase64String(bytes);
            }
        }

        // Удалить отзыв
        public static string DeleteReview(Review review)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "DELETE FROM Reviews WHERE Id = @id",
                    connection);

                command.Parameters.AddWithValue("@id", review.Id);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0
                        ? $"Комментарий {review.Comment} успешно удален!"
                        : "Не удалось удалить комментарий";
                }
                catch (Exception ex)
                {
                    return $"Ошибка при удалении комментария: {ex.Message}";
                }
            }
        }

        // Удалить заказ
        public static string DeletePurchase(Purchase purchase)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var command = new SqlCommand(
                    "DELETE FROM Purchases WHERE Id = @id",
                    connection);

                command.Parameters.AddWithValue("@id", purchase.Id);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    return rowsAffected > 0
                        ? $"Заказ пользователя {purchase.UserId} успешно удален!"
                        : "Не удалось удалить заказ";
                }
                catch (Exception ex)
                {
                    return $"Ошибка при удалении заказа: {ex.Message}";
                }
            }
        }

        // Удалить продукт
        public static string DeleteProduct(Product product)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var transaction = connection.BeginTransaction();

                try
                {
                    // 1. Удалить связанные отзывы
                    var deleteReviewsCommand = new SqlCommand(
                        "DELETE FROM Reviews WHERE ProductId = @productId",
                        connection, transaction);
                    deleteReviewsCommand.Parameters.AddWithValue("@productId", product.Id);
                    deleteReviewsCommand.ExecuteNonQuery();

                    // 2. Удалить связанные покупки
                    var deletePurchasesCommand = new SqlCommand(
                        "DELETE FROM Purchases WHERE ProductId = @productId",
                        connection, transaction);
                    deletePurchasesCommand.Parameters.AddWithValue("@productId", product.Id);
                    deletePurchasesCommand.ExecuteNonQuery();

                    // 3. Удалить продукт
                    var deleteProductCommand = new SqlCommand(
                        "DELETE FROM Products WHERE Id = @id",
                        connection, transaction);
                    deleteProductCommand.Parameters.AddWithValue("@id", product.Id);
                    int rowsAffected = deleteProductCommand.ExecuteNonQuery();

                    transaction.Commit();

                    return rowsAffected > 0
                        ? $"Продукт {product.Name} успешно удален!"
                        : "Не удалось удалить продукт";
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return $"Ошибка при удалении продукта: {ex.Message}";
                }
            }
        }

        // Удалить пользователя
        public static string DeleteUser(User user)
        {
            using (var connection = new SqlConnection(connectionString))
            {
                var transaction = connection.BeginTransaction();

                try
                {
                    // 1. Удалить связанные отзывы
                    var deleteReviewsCommand = new SqlCommand(
                        "DELETE FROM Reviews WHERE UserId = @userId",
                        connection, transaction);
                    deleteReviewsCommand.Parameters.AddWithValue("@userId", user.Id);
                    deleteReviewsCommand.ExecuteNonQuery();

                    // 2. Удалить связанные покупки
                    var deletePurchasesCommand = new SqlCommand(
                        "DELETE FROM Purchases WHERE UserId = @userId",
                        connection, transaction);
                    deletePurchasesCommand.Parameters.AddWithValue("@userId", user.Id);
                    deletePurchasesCommand.ExecuteNonQuery();

                    // 3. Удалить пользователя
                    var deleteUserCommand = new SqlCommand(
                        "DELETE FROM Users WHERE Id = @id",
                        connection, transaction);
                    deleteUserCommand.Parameters.AddWithValue("@id", user.Id);
                    int rowsAffected = deleteUserCommand.ExecuteNonQuery();

                    transaction.Commit();

                    return rowsAffected > 0
                        ? $"Пользователь {user.Login} успешно удален!"
                        : "Не удалось удалить пользователя";
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return $"Ошибка при удалении пользователя: {ex.Message}";
                }
            }
        }

        // редактировать продукт
        public static string EditProduct(Product oldProduct, Category newCategory,
    Manufacturer newManufacturer, string newName, int newQuantity,
    string newPriceStr, string newDescription, byte[] newImageData)
        {
            // Валидация параметров
            if (newCategory == null)
                return "Не указана категория продукта";

            if (newManufacturer == null)
                return "Не указан производитель";

            if (string.IsNullOrWhiteSpace(newName))
                return "Не указано название продукта";

            if (newName.Length < 2)
                return "Название продукта должно содержать не менее 2 символов";

            if (newQuantity <= 0)
                return "Не указано количество продукта";

            if (string.IsNullOrWhiteSpace(newPriceStr))
                return "Цена должна быть указана";

            // Нормализация цены
            string normalizedPrice = newPriceStr.Trim()
                                                .Replace(" ", "")
                                                .Replace(",", ".");

            if (!decimal.TryParse(normalizedPrice, NumberStyles.Any, CultureInfo.InvariantCulture, out decimal newPrice) || newPrice <= 0)
                return "Цена должна быть числом больше нуля";

            if (string.IsNullOrWhiteSpace(newDescription))
                return "Не указано описание продукта";

            if (newDescription.Length < 10)
                return "Описание товара должно содержать не менее 10 символов";

            if (newImageData == null || newImageData.Length == 0)
                return "Не добавлено изображение товара";

            string connectionString = "your_connection_string_here"; // Замените на вашу строку подключения

            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Проверка наличия продукта
                string checkQuery = "SELECT COUNT(*) FROM Products WHERE Id = @Id";
                using (var checkCmd = new SqlCommand(checkQuery, connection))
                {
                    checkCmd.Parameters.AddWithValue("@Id", oldProduct.Id);
                    int count = (int)checkCmd.ExecuteScalar();
                    if (count == 0)
                        return "Продукт не найден!";
                }

                // Обновление продукта
                string updateQuery = @"
            UPDATE Products
            SET CategoryId = @CategoryId,
                ManufacturerId = @ManufacturerId,
                Name = @Name,
                Quantity = @Quantity,
                Price = @Price,
                Description = @Description,
                ImageData = @ImageData
            WHERE Id = @Id";

                using (var updateCmd = new SqlCommand(updateQuery, connection))
                {
                    updateCmd.Parameters.AddWithValue("@CategoryId", newCategory.Id);
                    updateCmd.Parameters.AddWithValue("@ManufacturerId", newManufacturer.Id);
                    updateCmd.Parameters.AddWithValue("@Name", newName);
                    updateCmd.Parameters.AddWithValue("@Quantity", newQuantity);
                    updateCmd.Parameters.AddWithValue("@Price", newPrice);
                    updateCmd.Parameters.AddWithValue("@Description", newDescription);
                    updateCmd.Parameters.AddWithValue("@ImageData", newImageData);
                    updateCmd.Parameters.AddWithValue("@Id", oldProduct.Id);

                    int rowsAffected = updateCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                        return $"Продукт \"{newName}\" успешно изменён!";
                    else
                        return "Ошибка при обновлении продукта.";
                }
            }
        }

        // Вспомогательная функция для хеширования пароля
        private static string HashPassword(string password)
        {
            // Реализуйте хеширование пароля (например, с помощью BCrypt или SHA256)
            return password; // В реальном приложении не храните пароли в открытом виде!
        }

    }

    public static class Hashing
    {
        public static string GenerateSalt()
        {
            // Генерация соли
            return Guid.NewGuid().ToString("N");
        }

        public static string HashPassword(string password, string salt)
        {
            // Пример простого хеширования (в реальном приложении используйте более надежные методы)
            using (var sha256 = System.Security.Cryptography.SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password + salt));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }
    }
}
