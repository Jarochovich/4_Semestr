﻿

//namespace ADO.Model.Data
//{
//    public class ApplicationContext : DbContext
//    {
//        public DbSet<Category> Categories { get; set; }
//        public DbSet<Product> Products { get; set; }
//        public DbSet<User> Users { get; set; }
//        public DbSet<Manufacturer> Manufacturers { get; set; }
//        public DbSet<Purchase> Purchases { get; set; }
//        public DbSet<Review> Reviews { get; set; }

//        public ApplicationContext()
//        {
//            Database.EnsureCreated();
//        }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            base.OnConfiguring(optionsBuilder);
//            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=ADO;Trusted_Connection=true");
//        }
//    }
//}
