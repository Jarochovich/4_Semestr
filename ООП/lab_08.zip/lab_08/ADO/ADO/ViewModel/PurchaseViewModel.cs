﻿using ADO.Model;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace ADO.ViewModel
{
    public class PurchaseViewModel : BaseViewModel, INotifyPropertyChanged
    {
        private Product _product;
        private string _comment;
        private int _rating;
        private bool _hasUserReviewed;

        public Purchase Purchase { get; set; }

        public Product Product
        {
            get => _product;
            set
            {
                _product = value;
                OnPropertyChanged(nameof(Product));
                OnPropertyChanged(nameof(ProductName));
                OnPropertyChanged(nameof(ProductImage));
            }
        }

        public string ProductName => Product?.Name ?? "Неизвестный товар";
        public byte[] ProductImage => Product?.ImageData;
        public decimal TotalPrice => (Purchase?.PriceAtPurchase ?? 0) * (Purchase?.Quantity ?? 0);
        public string PurchaseDate => Purchase?.PurchaseDate.ToString("dd.MM.yyyy");

        public bool HasUserReviewed
        {
            get => _hasUserReviewed;
            set
            {
                _hasUserReviewed = value;
                OnPropertyChanged(nameof(HasUserReviewed));
            }
        }

        public string Comment
        {
            get => _comment;
            set
            {
                _comment = value;
                OnPropertyChanged(nameof(Comment));
            }
        }

        public int Rating
        {
            get => _rating;
            set
            {
                _rating = value;
                OnPropertyChanged(nameof(Rating));
                UpdateStars();
            }
        }

        public ObservableCollection<StarItem> Stars { get; } = new ObservableCollection<StarItem>();

        public ICommand SetRatingCommand => new RelayCommand(obj =>
        {
            if (obj is int value)
                Rating = value;
        });

        public PurchaseViewModel(Purchase purchase)
        {
            Purchase = purchase;
            InitializeStars();
            LoadProduct();
        }

        public void LoadProduct()
        {
            try
            {
                using (var connection = new SqlConnection(DataWorker.connectionString))
                {
                    connection.Open();

                    // Загрузка продукта с производителем
                    var productCommand = new SqlCommand(@"
                    SELECT p.Id, p.Name, p.Price, p.Description, p.ImageData, p.ManufacturerId,
                           m.Name AS ManufacturerName
                    FROM Products p
                    JOIN Manufacturers m ON p.ManufacturerId = m.Id
                    WHERE p.Id = @productId", connection);

                    productCommand.Parameters.AddWithValue("@productId", Purchase.ProductId);

                    using (var reader = productCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Product = new Product
                            {
                                Id = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Price = reader.GetDecimal(2),
                                Description = reader.GetString(3),
                                ImageData = reader.IsDBNull(4) ? null : (byte[])reader[4],
                                ManufacturerId = reader.GetInt32(5),
                                Manufacturer = new Manufacturer
                                {
                                    Id = reader.GetInt32(5),
                                    Name = reader.GetString(6)
                                }
                            };
                        }
                    }

                    // Проверка наличия отзыва
                    var reviewCommand = new SqlCommand(@"
                    SELECT Comment, Rating FROM Reviews 
                    WHERE UserId = @userId AND ProductId = @productId", connection);

                    reviewCommand.Parameters.AddWithValue("@userId", Purchase.UserId);
                    reviewCommand.Parameters.AddWithValue("@productId", Purchase.ProductId);

                    using (var reader = reviewCommand.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            HasUserReviewed = true;
                            Comment = reader.IsDBNull(0) ? null : reader.GetString(0);
                            Rating = reader.GetInt32(1);
                        }
                        else
                        {
                            HasUserReviewed = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ShowMessageToUser($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void InitializeStars()
        {
            Stars.Clear();
            for (int i = 1; i <= 5; i++)
            {
                Stars.Add(new StarItem
                {
                    Value = i,
                    IsFilled = i <= Rating
                });
            }
        }

        public void UpdateStars()
        {
            foreach (var star in Stars)
            {
                star.IsFilled = star.Value <= Rating;
            }
            OnPropertyChanged(nameof(Stars));
        }

        public void RefreshReviewStatus()
        {
            try
            {
                using (var connection = new SqlConnection(DataWorker.connectionString))
                {
                    var command = new SqlCommand(
                        "SELECT COUNT(1) FROM Reviews WHERE UserId = @userId AND ProductId = @productId",
                        connection);

                    command.Parameters.AddWithValue("@userId", Purchase.UserId);
                    command.Parameters.AddWithValue("@productId", Purchase.ProductId);

                    connection.Open();
                    HasUserReviewed = (int)command.ExecuteScalar() > 0;
                }
            }
            catch (Exception ex)
            {
                ShowMessageToUser($"Ошибка обновления статуса отзыва: {ex.Message}");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}