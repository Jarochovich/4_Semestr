﻿using ADO;
using ADO.Helpers;
using ADO.Model;
using ADO.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace ADO.ViewModel
{
    public class BaseViewModel : INotifyPropertyChanged
    {
        private bool _isDarkTheme;
        public bool IsDarkTheme
        {
            get => _isDarkTheme;
            set
            {
                if (_isDarkTheme != value)
                {
                    _isDarkTheme = value;
                    ThemeManagerHelper.SetDarkTheme(_isDarkTheme);
                }
            }
        }

        // Языки
        public ICommand SetRussianCommand { get; }
        public ICommand SetEnglishCommand { get; }

        public BaseViewModel()
        {
            _isDarkTheme = ThemeManagerHelper.IsDarkTheme();
            ThemeManagerHelper.SetDarkTheme(_isDarkTheme);


            SetRussianCommand = new RelayCommand(_ => App.ChangeLanguage("ru"));
            SetEnglishCommand = new RelayCommand(_ => App.ChangeLanguage("en"));
            
        }

        // Пользовательское окно вывода инфы
        public void ShowMessageToUser(string message)
        {
            MessageView messageView = new MessageView
            {
                DataContext = new MessageViewModel(message)
            };
            messageView.ShowDialog();
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

