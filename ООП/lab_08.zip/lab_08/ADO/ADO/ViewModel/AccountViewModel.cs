﻿using ADO.Model;
using ADO.View;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Microsoft.VisualBasic;
using SharpVectors.Dom;
using System.Windows.Media;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace ADO.ViewModel
{
    public class AccountViewModel : BaseViewModel
    {

        public ICommand SaveUserChangesCommand { get; }


        public event Action<int, int> ProductQuantityUpdated; // productId, delta
        private User _currentUser;
        public User CurrentUser
        {
            get => _currentUser;
            set
            {
                _currentUser = value;
                OnPropertyChanged(nameof(CurrentUser));
                OnPropertyChanged(nameof(BalanceDisplay));
            }
        }

        public string BalanceDisplay => $"{CurrentUser?.Balance ?? 0} BYN";

        public ObservableCollection<PurchaseViewModel> PendingPurchases { get; } = new();
        public ObservableCollection<PurchaseViewModel> ConfirmedPurchases { get; } = new();
        public ObservableCollection<Product> PurchasedProducts { get; } = new();
        public ObservableCollection<ProductReviewViewModel> ProductReviews { get; } = new();
        

        public ICommand BackToMainCommand { get; }
        public ICommand TopUpBalanceCommand { get; }
        public ICommand ConfirmPurchaseCommand { get; }
        public ICommand CancelPurchaseCommand { get; }

        private ICommand _submitReviewCommand;
        public ICommand SubmitReviewCommand => _submitReviewCommand ??= new RelayCommand(SubmitReview);

        public AccountViewModel(User user)
        {
            CurrentUser = user;

            BackToMainCommand = new RelayCommand(_ => BackToMain());
            TopUpBalanceCommand = new RelayCommand(_ => TopUpBalance());
            _submitReviewCommand = new RelayCommand(SubmitReview);
            ConfirmPurchaseCommand = new RelayCommand(ConfirmPurchase);
            CancelPurchaseCommand = new RelayCommand(CancelPurchase);
            SaveUserChangesCommand = new RelayCommand(_ => SaveUserChanges());

            LoadPurchasedProducts();
            LoadPurchases();
        }

        private void SaveUserChanges()
        {
            if (CurrentUser != null)
            {
                DataWorker.UpdateUser(CurrentUser); // Предполагается, что ты реализовал этот метод
                MessageBox.Show("Данные успешно сохранены!");
            }
        }

        private void LoadPurchases()
        {
            LoadPendingPurchases();
            LoadConfirmedPurchases();
        }

        private void LoadPendingPurchases()
        {
            try
            {
                if (CurrentUser?.Id == null) return;

                PendingPurchases.Clear();
                var pending = DataWorker.GetPendingPurchases(CurrentUser.Id);
                foreach (var p in pending)
                    PendingPurchases.Add(new PurchaseViewModel(p));
            }
            catch (Exception ex)
            {
                ShowMessageToUser($"Ошибка загрузки заказов: {ex.Message}");
            }
        }

        private void LoadConfirmedPurchases()
        {
            try
            {
                if (CurrentUser?.Id == null) return;

                ConfirmedPurchases.Clear();
                var confirmed = DataWorker.GetConfirmedPurchasesByUserId(CurrentUser.Id);
                foreach (var p in confirmed)
                {
                    var vm = new PurchaseViewModel(p);
                    vm.LoadProduct();
                    ConfirmedPurchases.Add(vm);
                }
            }
            catch (Exception ex)
            {
                ShowMessageToUser($"Ошибка загрузки истории: {ex.Message}");
            }
        }

        private void LoadPurchasedProducts()
        {
            if (CurrentUser?.Id == null)
            {
                ShowMessageToUser("Пользователь не авторизован");
                return;
            }

            PurchasedProducts.Clear();
            ProductReviews.Clear();

            var products = DataWorker.GetPurchasedProducts(CurrentUser.Id);
            

            foreach (var product in products)
            {
                PurchasedProducts.Add(product);
                ProductReviews.Add(new ProductReviewViewModel
                {
                    Product = product,
                    HasUserReviewed = DataWorker.UserHasReviewedProduct(CurrentUser.Id, product.Id)
                });
            }
        }

        private void ConfirmPurchase(object parameter)
        {
            if (parameter is PurchaseViewModel purchaseVM)
            {
                purchaseVM.Purchase.Status = Purchase.PurchaseStatus.Confirmed;

                using (var connection = new SqlConnection(DataWorker.connectionString))
                {
                    connection.Open();

                    string updateQuery = "UPDATE Purchases SET Status = @Status WHERE Id = @Id";
                    using (var command = new SqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@Status", (int)purchaseVM.Purchase.Status);
                        command.Parameters.AddWithValue("@Id", purchaseVM.Purchase.Id);

                        if (command.ExecuteNonQuery() > 0)
                        {
                            PendingPurchases.Remove(purchaseVM);
                            ConfirmedPurchases.Add(purchaseVM);
                            LoadPurchasedProducts();
                            ShowMessageToUser("Заказ подтвержден и перемещен в архив!");
                        }
                        else
                        {
                            ShowMessageToUser("Ошибка при подтверждении заказа.");
                        }
                    }
                }
            }
        }

        private void CancelPurchase(object parameter)
        {
            if (parameter is PurchaseViewModel purchaseVM)
            {
                using (var connection = new SqlConnection(DataWorker.connectionString))
                {
                    connection.Open();
                    var transaction = connection.BeginTransaction();

                    try
                    {
                        // Удаляем покупку
                        var cancelCommand = new SqlCommand("DELETE FROM Purchases WHERE Id = @Id", connection, transaction);
                        cancelCommand.Parameters.AddWithValue("@Id", purchaseVM.Purchase.Id);
                        cancelCommand.ExecuteNonQuery();

                        // Возвращаем деньги пользователю
                        var refundCommand = new SqlCommand("UPDATE Users SET Balance = Balance + @Amount WHERE Id = @UserId", connection, transaction);
                        refundCommand.Parameters.AddWithValue("@Amount", purchaseVM.TotalPrice);
                        refundCommand.Parameters.AddWithValue("@UserId", CurrentUser.Id);
                        refundCommand.ExecuteNonQuery();

                        // Возвращаем товар на склад
                        var updateProductCmd = new SqlCommand("UPDATE Products SET Quantity = Quantity + @Qty WHERE Id = @ProductId", connection, transaction);
                        updateProductCmd.Parameters.AddWithValue("@Qty", purchaseVM.Purchase.Quantity);
                        updateProductCmd.Parameters.AddWithValue("@ProductId", purchaseVM.Product.Id);
                        updateProductCmd.ExecuteNonQuery();

                        transaction.Commit();

                        CurrentUser.Balance += purchaseVM.TotalPrice;
                        OnPropertyChanged(nameof(CurrentUser));
                        OnPropertyChanged(nameof(BalanceDisplay));

                        PendingPurchases.Remove(purchaseVM);

                        // Обновляем количество
                        purchaseVM.Product.Quantity += purchaseVM.Purchase.Quantity;
                        ProductQuantityUpdated?.Invoke(purchaseVM.Product.Id, purchaseVM.Purchase.Quantity);

                        ShowMessageToUser("Заказ отменен. Деньги возвращены на баланс. Товар возвращен на склад.");
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        ShowMessageToUser($"Ошибка при отмене заказа: {ex.Message}");
                    }
                }
            }
        }


        private void SubmitReview(object parameter)
        {
            if (parameter is PurchaseViewModel purchaseVM)
            {
                if (string.IsNullOrWhiteSpace(CurrentUser.Login))
                {
                    ShowMessageToUser("Не указано имя пользователя");
                    return;
                }

                if (purchaseVM.HasUserReviewed)
                {
                    ShowMessageToUser("Вы уже оставили отзыв на этот товар.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(purchaseVM.Comment) || purchaseVM.Comment.Length < 10)
                {
                    ShowMessageToUser("Отзыв должен содержать минимум 10 символов.");
                    return;
                }

                if (purchaseVM.Rating < 1 || purchaseVM.Rating > 5)
                {
                    ShowMessageToUser("Пожалуйста, поставьте оценку от 1 до 5 звезд.");
                    return;
                }

                try
                {
                    using (var connection = new SqlConnection(DataWorker.connectionString))
                    {
                        connection.Open();
                        var command = new SqlCommand(@"
                    INSERT INTO Reviews (UserId, ProductId, AuthorName, Comment, Rating, DateCreated)
                    VALUES (@UserId, @ProductId, @AuthorName, @Comment, @Rating, @DateCreated)", connection);

                        command.Parameters.AddWithValue("@UserId", CurrentUser.Id);
                        command.Parameters.AddWithValue("@ProductId", purchaseVM.Product.Id);
                        command.Parameters.AddWithValue("@AuthorName", CurrentUser.Login);
                        command.Parameters.AddWithValue("@Comment", purchaseVM.Comment.Trim());
                        command.Parameters.AddWithValue("@Rating", purchaseVM.Rating);
                        command.Parameters.AddWithValue("@DateCreated", DateTime.Now);

                        command.ExecuteNonQuery();
                        purchaseVM.HasUserReviewed = true;

                        ShowMessageToUser("Спасибо за ваш отзыв!");
                        LoadPurchasedProducts();
                    }
                }
                catch (Exception ex)
                {
                    ShowMessageToUser($"Ошибка сохранения отзыва: {ex.Message}");
                }
            }
        }


        private void TopUpBalance()
        {
            var inputDialog = new InputDialog("Пополнение баланса", "Введите сумму для пополнения:");
            if (inputDialog.ShowDialog() == true)
            {
                if (decimal.TryParse(inputDialog.Answer, out decimal amount) && amount > 0)
                {
                    using (var connection = new SqlConnection(DataWorker.connectionString))
                    {
                        connection.Open();

                        var command = new SqlCommand("UPDATE Users SET Balance = Balance + @Amount WHERE Id = @Id", connection);
                        command.Parameters.AddWithValue("@Amount", amount);
                        command.Parameters.AddWithValue("@Id", CurrentUser.Id);

                        if (command.ExecuteNonQuery() > 0)
                        {
                            CurrentUser.Balance += amount;
                            OnPropertyChanged(nameof(CurrentUser));
                            OnPropertyChanged(nameof(BalanceDisplay));
                            ShowMessageToUser($"Баланс успешно пополнен на {amount} BYN");
                        }
                        else
                        {
                            ShowMessageToUser("Ошибка при пополнении баланса");
                        }
                    }
                }
                else
                {
                    ShowMessageToUser("Введите корректную сумму (положительное число)");
                }
            }
        }

        private void BackToMain()
        {
            foreach (Window window in Application.Current.Windows)
            {
                if (window is AccountView)
                {
                    window.Close();
                    break;
                }
            }
        }
    }

    public class InputDialog
    {
        public string Title { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }

        public InputDialog(string title, string question)
        {
            Title = title;
            Question = question;
        }

        public bool? ShowDialog()
        {
            Window window = new Window()
            {
                Title = Title,
                Width = 300,
                Height = 150,
                WindowStartupLocation = WindowStartupLocation.CenterScreen
            };

            StackPanel panel = new StackPanel() { Margin = new Thickness(10) };

            panel.Children.Add(new TextBlock() { Text = Question, Margin = new Thickness(0, 0, 0, 10) });

            TextBox textBox = new TextBox();
            panel.Children.Add(textBox);

            Button okButton = new Button()
            {
                Content = "OK",
                Width = 70,
                Margin = new Thickness(0, 10, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Right
            };

            okButton.Click += (sender, e) =>
            {
                Answer = textBox.Text;
                window.DialogResult = true;
            };

            panel.Children.Add(okButton);

            window.Content = panel;
            return window.ShowDialog();
        }
    }
}